package dataRead;

import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffLoader;

public class ArffRead {
	public Instances getInstances(String source) throws Exception {
		File input = new File(source);
		ArffLoader arf = new ArffLoader();
		arf.setFile(input);
		Instances instances = arf.getDataSet();

		return instances;
	}

	public double[][] getAttribute(Instances instances, int start, int end, int C) {
		// TODO Auto-generated method stub

		int N = end - start;

		double[][] attribute = new double[N][C];

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < C; j++) {
				attribute[i][j] = instances.instance(i + start).value(j);
			}
		}

		return attribute;
	}

	public double[] getDetermine(Instances instances, int start, int end) {
		int N = end - start;

		double[] determine = new double[N];

		for (int i = 0; i < N; i++) {
			determine[i] = instances.instance(i + start).classValue();
		}

		return determine;
	}

}
