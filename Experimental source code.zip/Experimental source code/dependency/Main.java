package dependency;

import java.util.ArrayList;

import dataRead.ArffRead;
import interval.Interval;
import interval.Normal;
import weka.core.Instances;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		String sourceFile = "instance\\Wred.arff";

		ArffRead arff = new ArffRead();

		Instances instances = arff.getInstances(sourceFile);

		final int N = instances.numInstances(), P = instances.numAttributes();// �������������������Ը���
		instances.setClassIndex(P - 1);

		final int numClasses = instances.numClasses();// ������

		int start = N * 0 / 100, end = N * 90 / 100;// start��ʾ������ʼλ�ã�end��ʾ���ݽ���λ��

		double[][] attribute = arff.getAttribute(instances, start, end, P - 1);

		ArrayList<Integer> list = new ArrayList<Integer>();

		for (int i = 0; i < P - 1; i++)
			list.add(i);

		Normal.normal(attribute);

		double[][] attribute_Inter = Interval.interval(attribute);

		double[] determine = arff.getDetermine(instances, start, end);

		Dependency dependency = new Dependency();
		System.out.println("��C�ϵ������ȣ�" + dependency.attrDependency(attribute_Inter, determine, numClasses));

		System.out.println();
		System.out.println("-------DRSQR�㷨-------");
		long startTime = System.currentTimeMillis();
		DRSQR DRSQR = new DRSQR();
		DRSQR.algorithm(attribute_Inter, determine, numClasses, list);
		long endTime = System.currentTimeMillis();
		System.out.println("DRSQR�㷨������ʱ�䣺" + (endTime - startTime) + "ms");

//		System.out.println();
//		System.out.println("-------HARCC�㷨-------");
//		long startTime1 = System.currentTimeMillis();
//		HARCC HARCC = new HARCC();
//		HARCC.algorithm(attribute_Inter, determine, numClasses, list);
//		long endTime1 = System.currentTimeMillis();
//		System.out.println("HARCC�㷨������ʱ�䣺" + (endTime1 - startTime1) + "ms");
	}

}
