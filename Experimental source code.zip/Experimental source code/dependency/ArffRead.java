package dependency;

import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffLoader;

public class ArffRead {

	/**
	 * @author dapeng
	 * @function ��ȡarff�����ļ���
	 * @param sourceFile Դ�ļ�·��
	 * @return Instances���͵����ݼ�
	 * @throws Exception
	 */
	public Instances getArff(String sourceFile) throws Exception {

		File input = new File(sourceFile);
		ArffLoader arff = new ArffLoader();
		arff.setFile(input);
		Instances instances = arff.getDataSet();// ��ȡInstances���͵�����

		return instances;
	}

	public void attibuteToDoubleArray(Instances instances, double[][] attribute, int start, int end) {

		int C = instances.numAttributes() - 1;

		for (int i = start; i < end; i++) {
			for (int j = 0; j < C; j++) {
				attribute[i - start][j] = instances.instance(i).value(j);
			}
		}
	}

	public void determineToDoubleArray(Instances instances, double[] determine, int start, int end, int index) {
		for (int i = start; i < end; i++) {
			determine[i - start] = instances.instance(i).value(index);
		}
	}

}
