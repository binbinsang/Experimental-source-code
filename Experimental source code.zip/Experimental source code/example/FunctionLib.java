package example;

public class FunctionLib {

	public static void showIntegerArray(int[] array) {//��Ļ��ʾһ��һά��������
		int n = array.length;
		for(int i=0;i<n;i++) {
			System.out.print(array[i]+"\t");
		}
		System.out.println();
	}
	
	public static int[] findUpperJoint(double[][] determineSet, int d) {//�ҵ�d�������������
		int n = determineSet.length;
		int[] upperSet = new int[n];
		int z=0;//z���������ϵ������ĸ���
		for(int i=0;i<n;i++) {
			if(determineSet[i][0]>=d) {
				upperSet[z] = i;
				z++;
			}
		}
		int[] result = new int[z];
		for(int i=0;i<z;i++) {
			result[i] = upperSet[i];
		}
		return result;
	}
	
	public static int[] findDominanceSet(double[][] attributeSet, int t) {//�ҵ�t����������Ƽ�
		int n = attributeSet.length, p = attributeSet[0].length;
		int flag = 1, z = 0;
		int[] dominanceSet = new int [n];
		for(int i=0;i<n;i++) {
			flag = 1;
			for(int j=0;j<p;j++) {
				if(attributeSet[i][j]<attributeSet[t][j]) {
					flag = 0;
				}
				else ;
			}
			if(flag==1) {
				dominanceSet[z] = i;
				z++;
			}
		}
		int[] result = new int [z];
		for(int i=0;i<z;i++) {
			result[i] = dominanceSet[i];
		}
		return result;
	}
	
	public static int[] findInferiorSet(double[][] attributeSet, int t) {//�ҵ�t����������Ƽ�
		int n = attributeSet.length, p = attributeSet[0].length;
		int flag = 1, z = 0;
		int[] inferiorSet = new int [n];
		for(int i=0;i<n;i++) {
			flag = 1;
			for(int j=0;j<p;j++) {
				if(attributeSet[i][j]>attributeSet[t][j]) {
					flag = 0;
				}
				else ;
			}
			if(flag==1) {
				inferiorSet[z] = i;
				z++;
			}
		}
		int[] result = new int [z];
		for(int i=0;i<z;i++) {
			result[i] = inferiorSet[i];
		}
		return result;
	}
	
	public static int relationOfSet1AndSet2(int[] Set1, int[] Set2) {//Set1Ϊ�������ϼ���Set2Ϊ���Ƽ���
																	//�ж����������ϵĹ�ϵ��0��ʾ���������Ͻ���Ϊ�ռ���1��ʾ�������ϵĽ�����Ϊ�գ�2��ʾ����1��������2
		int n1 = Set1.length, n2 = Set2.length;
		int judge = 0;
		int count = 0;
		for(int i=0;i<n1;i++) {
			for(int j=0;j<n2;j++) {
				if(Set1[i]==Set2[j]) {
					count++;
				}
			}
		}
		if(count == 0) 
			judge = 0;
		if(count > 0 && count < n2) 
			judge = 1;
		if(count == n2) 
			judge = 2;
		return judge;
	}
	
	public static int[] addOneData(int[] Set, int data) {//һά������������һ���µ���
		int n = Set.length;
		int[] result = new int [n+1];
		for(int i=0;i<n;i++) {
			result[i] = Set[i];
		}
		result[n] = data;
		return result;
	}
	
	public static int[] set1Subset2(int[] set1, int[] set2) {//����1��ȥ����2���õļ���
		int n1=set1.length,n2=set2.length;
		int count = 0;
		for(int i=0;i<n1;i++) {
			for(int j=0;j<n2;j++) {
				if(set1[i]==set2[j]) {
					set1[i]=-1;
					count++;
				}
			}
		}
		int z=0;
		int[] sub = new int[n1-count];
		for(int j=0;j<n1;j++) {
			if(set1[j]!=-1) {
				sub[z]=set1[j];
				z++;
			}
		}			
		return sub;
	}
	
	public static int[] unionSet12(int[] set1, int[] set2) {//���ϵĲ�
		int n1 = set1.length, n2 = set2.length;
		int count = 0;
		int[] union = new int[n1+n2];
		for(int i=0;i<n1;i++) {
			for(int j=0;j<n2;j++) {
				if(set1[i]==set2[j]) {
					set2[j]=-1;
					count++;
				}
			}
		}
		for(int i=0;i<n1;i++) {
			union[i]=set1[i];
		}
		for(int j=0;j<n2;j++) {
			union[n1+j]=set2[j];			
		}
		int[] result = new int[n1+n2-count];
		int z=0;
		for(int k=0;k<n1+n2;k++) {
			if(union[k]!=-1) {
				result[z] = union[k];
				z++;
			}
		}
		return result;
	}	
	
	public static double[][] getReduceSet(double[][] universeSet, int[] labelOfReduceSet) {
		double[][] reduceSet = base.splitBinaryArray(universeSet, labelOfReduceSet[0], 1);
		for(int i=1;i<labelOfReduceSet.length;i++) {
			reduceSet = base.combineColumn(reduceSet, base.splitBinaryArray(universeSet, labelOfReduceSet[i], 1));
		}
		return reduceSet;
	}
	
}//��
