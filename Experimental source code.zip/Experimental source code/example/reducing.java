package example;

public class reducing {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		//�������������ϵõ�һ��Լ��RED
		double[][] universeSet = instanceReader.getAllData();
		int i=0;
		int N=universeSet.length, P=universeSet[0].length;
		double[][] allAttributeSet = base.splitBinaryArray(universeSet, P-1, 0);
		double[][] determineSet = base.splitBinaryArray(universeSet, P-1, 1);
		
		double[][] dMofD = base.establishDimananceMetrix(determineSet);
		double[][] dMofC = base.establishDimananceMetrix(allAttributeSet);
		double[][] dMofCD = base.infTwoMetrix(dMofC, dMofD);
		double[] numOfDimOnCandD = base.calculateSumOfRow(dMofCD);
		double[] numOfDimOnC = base.calculateSumOfRow(dMofC);
		double DHonC=base.calculateDH(numOfDimOnCandD, numOfDimOnC);
		
		System.out.println("���������������Լ�C�;������Լ�D�ϵ����������Ϊ��");
		base.showArray(numOfDimOnCandD);
		System.out.println("���������������Լ�C�ϵ����������Ϊ��");
		base.showArray(numOfDimOnC);
		System.out.println("���������Լ�C�ϵ�����������Ϊ��");
		System.out.println(DHonC);
		
		double[] sigInner = new double[P-1];
		for(i=0;i<P-1;i++) {
			double[][] B = base.splitBinaryArray(allAttributeSet, i, 0);			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			sigInner[i] = base.calculateDH(numOfDimOnBandD, numOfDimOnB)-DHonC;
			System.out.println("��"+i+"�����Ե�����Ҫ��Ϊ��"+sigInner[i]);
		}
		
		int countOfRED = 0;
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				countOfRED++;
			}
		}
		int countOfNoRED = P-1-countOfRED;
		int t1=0,t2=0;
		double[] labelOfRED = new double[countOfRED];
		double[] labelOfNoRED = new double[countOfNoRED];
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				labelOfRED[t1]=i;
				t1++;
			}
			else {
				labelOfNoRED[t2]=i;
				t2++;
			}
		}
		double[][] RED = new double[2][2];
		if(labelOfRED.length==0) {
			double[] hyber = new double[1];
			hyber[0]=0;
			RED = base.splitBinaryArray(allAttributeSet, 0, 1);
			countOfRED++;
			labelOfRED=base.combineTwoArray(labelOfRED, hyber);
			labelOfNoRED=base.splitArray(labelOfNoRED, 0, 0);
			countOfNoRED--;
		}
		else
			RED = base.splitBinaryArray(allAttributeSet, (int)labelOfRED[0], 1);
		base.showArray(labelOfRED);
		base.showArray(labelOfNoRED);
		for(i=1;i<countOfRED;i++) {
			RED = base.combineColumn(RED, base.splitBinaryArray(allAttributeSet, (int)labelOfRED[i], 1));
		}
		double[][] noRED = new double[N][1];
		if(labelOfNoRED.length==0) 
			;
		else
			noRED = base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			noRED = base.combineColumn(noRED, base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[i], 1));
		}
		
		double[][] dMofR = base.establishDimananceMetrix(RED);
		double[][] dMofRD = base.infTwoMetrix(dMofR, dMofD);
		double[] numOfDimOnRandD = base.calculateSumOfRow(dMofRD);
		double[] numOfDimOnR = base.calculateSumOfRow(dMofR);
		double DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
		
		System.out.println("������Ҫ�ȵó���Լ��RED�ϵ�������Ϊ��"+DHonR);
		
		while(DHonR!=DHonC) {
			System.out.println("");
			double[] sigOut = new double[countOfNoRED];
			for(i=0;i<countOfNoRED;i++) {
				double[][] B = base.combineColumn(RED, base.splitBinaryArray(noRED, i, 1));
				double[][] dMofB = base.establishDimananceMetrix(B);
				double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
				sigOut[i] =DHonR-base.calculateDH(numOfDimOnBandD, numOfDimOnB);
			}
			System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
			base.showArray(sigOut);
			double maxSigOut = sigOut[0];
			int remember = 0;
			for(i=1;i<countOfNoRED;i++) {
				if(maxSigOut<sigOut[i]) {
					maxSigOut=sigOut[i];
					remember = i;
				}
			}
			System.out.println("��"+(int)labelOfNoRED[remember]+"�����Է���Լ��RED�С�");
			RED = base.combineColumn(RED, base.splitBinaryArray(noRED, remember, 1));
			labelOfRED = base.combineTwoArray(labelOfRED, base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;
			
			noRED = base.splitBinaryArray(noRED, remember, 0);
			labelOfNoRED = base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;
			
			sigOut = base.splitArray(sigOut, remember, 0);
			
			if(countOfNoRED==-1) {
				System.out.println("�����ˣ�����");
				break;
			}
			
			dMofR = base.establishDimananceMetrix(RED);
			dMofRD = base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = base.calculateSumOfRow(dMofRD);
			numOfDimOnR = base.calculateSumOfRow(dMofR);
			
			DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��"+DHonR);
			
			if(DHonR == DHonC) {
				System.out.println("Լ�򼯺�RED����"+countOfRED+"�����ԡ��ֱ��ǣ�");
				base.showArray(labelOfRED);
			}
						
		}
		
		//���Լ�򼯺�RED���Ƿ�����������
		System.out.println("");
		System.out.println("���Լ�򼯺�RED���Ƿ�����������!");
		for(i=0;i<countOfRED;i++) {
			double[][] B = base.splitBinaryArray(RED, i, 0);			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			if(base.calculateDH(numOfDimOnBandD, numOfDimOnB)==DHonC) {
				RED=B;
				
				labelOfNoRED = base.combineTwoArray(labelOfNoRED, base.splitArray(labelOfRED, i, 1));
				countOfNoRED++;
				labelOfRED=base.splitArray(labelOfRED, i, 0);
				countOfRED--;
				i=0;
			}
		}
		//base.showBinaryArray(RED);
		System.out.println("���յ�Լ�򼯺�RED����"+countOfRED+"������.�ֱ���");
		base.showArray(labelOfRED);
		
		System.out.println("���ٶ���");
		//ȥ��percentage�ٷֱȵ�ʵ����
		long pre=System.currentTimeMillis();		
		int percentage =50;   //ȥ����ȫ�����ݼ��İٷֱ�                                                                                                                                             ;
		int reduce_length = N*percentage/100;
		
		double[][] newUniverse = base.shrinkMetrix(universeSet, reduce_length, 0);
		double[][] newAllAttribute = base.shrinkMetrix(allAttributeSet, reduce_length, 0);
		double[][] newDetermine = base.shrinkMetrix(determineSet, reduce_length, 0);
		double[][] adRED=base.splitBinaryArray(newAllAttribute, (int)labelOfRED[0], 1);
		for(i=1;i<countOfRED;i++) {
			adRED=base.combineColumn(adRED, base.splitBinaryArray(newAllAttribute, (int)labelOfRED[i], 1));
		}
		double[][] adNoRED = new double[2][2];
		if(labelOfNoRED.length==0) ;
		else
			adNoRED = base.splitBinaryArray(newAllAttribute, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			adNoRED = base.combineColumn(adNoRED, base.splitBinaryArray(newAllAttribute, (int)labelOfNoRED[i], 1));
		}
		
		//�ֱ����3�����ƾ������¼���������
		dMofD=base.shrinkMetrix(dMofD, reduce_length, reduce_length);
		
		dMofC=base.shrinkMetrix(dMofC, reduce_length, reduce_length);
		dMofCD = base.infTwoMetrix(dMofC, dMofD);
		numOfDimOnCandD = base.calculateSumOfRow(dMofCD);
		numOfDimOnC = base.calculateSumOfRow(dMofC);
		DHonC=base.calculateDH(numOfDimOnCandD, numOfDimOnC);
		System.out.println("���ٶ������C�ϵ�������Ϊ��"+DHonC);
		
		dMofR = base.establishDimananceMetrix(RED);
		
		System.out.println("");
		dMofR=base.shrinkMetrix(dMofR, reduce_length, reduce_length);
		//base.showBinaryArray(dMofR);
		dMofRD = base.infTwoMetrix(dMofR, dMofD);
		numOfDimOnRandD = base.calculateSumOfRow(dMofRD);
		numOfDimOnR = base.calculateSumOfRow(dMofR);
		DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
		System.out.println("���ٶ������Լ��R�ϵ�������Ϊ��"+DHonR);
		
		if(DHonR==DHonC) {
			System.out.println("");
			System.out.println("�����ٴ�Լ��Լ�򼯺�addRED����"+countOfRED+"������.�ֱ���");
			base.showArray(labelOfRED);
		}
		else {
		double[] sigOut1 = new double[countOfNoRED];
		for(i=0;i<countOfNoRED;i++) {
			double[][] B = base.combineColumn(adRED, base.splitBinaryArray(adNoRED, i, 1));	
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			sigOut1[i] = DHonR-base.calculateDH(numOfDimOnBandD, numOfDimOnB);
			System.out.println("��"+labelOfNoRED[i]+"�����Ե�����Ҫ��Ϊ"+sigOut1[i]);
		}
		
//		System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
//		base.showArray(sigOut1);
		while(DHonR!=DHonC) {
			
			double maxSigOut = sigOut1[0];
			int remember = 0;
			for(i=1;i<countOfNoRED;i++) {
				if(sigOut1[i]>maxSigOut) {
					maxSigOut=sigOut1[i];
					remember = i;
				}
			}
			System.out.println("��"+(int)labelOfNoRED[remember]+"�����Է���Լ��addRED�С�");
			adRED = base.combineColumn(adRED, base.splitBinaryArray(adNoRED, remember, 1));
			labelOfRED = base.combineTwoArray(labelOfRED, base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;

			
			adNoRED = base.splitBinaryArray(adNoRED, remember, 0);
			labelOfNoRED = base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;		
			
			sigOut1 = base.splitArray(sigOut1, remember, 0);
			
			dMofR = base.establishDimananceMetrix(adRED);
			dMofRD = base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = base.calculateSumOfRow(dMofRD);
			numOfDimOnR = base.calculateSumOfRow(dMofR);
			
			DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��"+DHonR);
			
			if(DHonR == DHonC) {
				System.out.println("Լ�򼯺�addRED����"+countOfRED+"�����ԡ��ֱ��ǣ�");
				base.showArray(labelOfRED);
			}
			if(countOfNoRED==0) {
				break;
			}			
		}
		}
		//���Լ�򼯺�RED���Ƿ�����������
		System.out.println("");
		System.out.println("���Լ�򼯺�addRED���Ƿ�����������!");
		for(i=0;i<countOfRED;i++) {
			int th =i;
			double[][] B = base.splitBinaryArray(adRED, i, 0);				
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			if(base.calculateDH(numOfDimOnBandD, numOfDimOnB)==DHonC) {
				adRED=B;
				labelOfNoRED = base.combineTwoArray(labelOfNoRED, base.splitArray(labelOfRED, i, 1));
				countOfNoRED++;
				labelOfRED=base.splitArray(labelOfRED, i, 0);
				countOfRED--;
				i=th-1;
			}
		}
		
		System.out.println("���յ�Լ�򼯺�addRED����"+countOfRED+"������.�ֱ���");
		base.showArray(labelOfRED);
		
		
		long post=System.currentTimeMillis();
		System.out.println("��������ʱ�䣺"+(post-pre)+"ms");	
	}//main
}//��

