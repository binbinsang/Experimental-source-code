package example;

public class Improv2Increasing {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		double[][] universeSet = dataProcess.getPrio50Data();
		int i=0,j=0;
		int N=universeSet.length, P=universeSet[0].length;
		double[][] allAttributeSet = base.splitBinaryArray(universeSet, P-1, 0);
		double[][] determineSet = base.splitBinaryArray(universeSet, P-1, 1);

		
		double[][] dMofD = base.establishDimananceMetrix(determineSet);
		double[][] dMofC = base.establishDimananceMetrix(allAttributeSet);
		double[][] dMofCD = base.infTwoMetrix(dMofC, dMofD);
		double[] numOfDimOnCandD = base.calculateSumOfRow(dMofCD);
		double[] numOfDimOnC = base.calculateSumOfRow(dMofC);
		double DHonC=base.calculateDH(numOfDimOnCandD, numOfDimOnC);
		
		System.out.println("���������������Լ�C�;������Լ�D�ϵ����������Ϊ��");
		base.showArray(numOfDimOnCandD);
		System.out.println("���������������Լ�C�ϵ����������Ϊ��");
		base.showArray(numOfDimOnC);
		System.out.println("���������Լ�C�ϵ�����������Ϊ��");
		System.out.println(DHonC);
		
		double[] sigInner = new double[P-1];
		for(i=0;i<P-1;i++) {
			double[][] B = base.splitBinaryArray(allAttributeSet, i, 0);
//			double[][] BandD = base.combineColumn(B, determineSet);
			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			sigInner[i] = base.calculateDH(numOfDimOnBandD, numOfDimOnB)-DHonC;
			System.out.println("��"+i+"�����Ե�����Ҫ��Ϊ��"+sigInner[i]);
		}
		
		int countOfRED = 0;
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				countOfRED++;
			}
		}
		int countOfNoRED = P-1-countOfRED;
		int t1=0,t2=0;
		double[] labelOfRED = new double[countOfRED];
		double[] labelOfNoRED = new double[countOfNoRED];
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				labelOfRED[t1]=i;
				t1++;
			}
			else {
				labelOfNoRED[t2]=i;
				t2++;
			}
		}
		
		double[][] RED = new double[2][2];
		if(labelOfRED.length==0) {
			double[] hyber = new double[1];
			hyber[0]=0;
			RED = base.splitBinaryArray(allAttributeSet, 0, 1);
			countOfRED++;
			labelOfRED=base.combineTwoArray(labelOfRED, hyber);
			labelOfNoRED=base.splitArray(labelOfNoRED, 0, 0);
			countOfNoRED--;
		}
		else
			RED = base.splitBinaryArray(allAttributeSet, (int)labelOfRED[0], 1);
		for(i=1;i<countOfRED;i++) {
			RED = base.combineColumn(RED, base.splitBinaryArray(allAttributeSet, (int)labelOfRED[i], 1));
		}
		double[][] noRED = new double[N][1];
		if(labelOfNoRED.length==0) 
			;
		else
			noRED = base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			noRED = base.combineColumn(noRED, base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[i], 1));
		}
		double[][] dMofR = base.establishDimananceMetrix(RED);
		double[][] dMofRandD = base.infTwoMetrix(dMofR, dMofD);
		double[] numOfDimOnRandD = base.calculateSumOfRow(dMofRandD);
		double[] numOfDimOnR = base.calculateSumOfRow(dMofR);
		double DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
		
		System.out.println("������Ҫ�ȵó���Լ��RED�ϵ�������Ϊ��"+DHonR);		
		
		while(DHonR>DHonC) {	
			double[] sigOut = new double[countOfNoRED];
			for(i=0;i<countOfNoRED;i++) {
				double[][] B = base.combineColumn(RED, base.splitBinaryArray(noRED, i, 1));
				double[][] dMofB = base.establishDimananceMetrix(B);
				double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
				sigOut[i] = DHonR-base.calculateDH(numOfDimOnBandD, numOfDimOnB);
			}
			System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
			base.showArray(sigOut);
			int remember = 0;
			
			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut[0];			
			for(i=0;i<countOfNoRED;i++) {
				if(maxSigOut<sigOut[i]) {
					maxSigOut=sigOut[i];
					remember = i;
				}
			}
			
			System.out.println("��"+(int)labelOfNoRED[remember]+"�����Է���Լ��RED�С�");
			RED = base.combineColumn(RED, base.splitBinaryArray(noRED, remember, 1));
			labelOfRED = base.combineTwoArray(labelOfRED, base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;
			
			noRED = base.splitBinaryArray(noRED, remember, 0);
			labelOfNoRED = base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;
			if(countOfNoRED==-1) {
				System.out.println("�����ˣ�����");
				break;
			}
			sigOut = base.splitArray(sigOut, remember, 0);
			
			dMofR = base.establishDimananceMetrix(RED);
			dMofRandD = base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = base.calculateSumOfRow(dMofR);
			
			DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��"+DHonR);
			
			if(DHonR <= DHonC) {
				System.out.println("Լ�򼯺�RED����"+countOfRED+"�����ԡ��ֱ��ǣ�");
				base.showArray(labelOfRED);
				break;
			}	
			
		}
		
		//���Լ�򼯺�RED���Ƿ�����������
		System.out.println("");
		System.out.println("���Լ�򼯺�RED���Ƿ�����������!");
		for(i=0;i<countOfRED;i++) {
			int th = i;
			double[][] B = base.splitBinaryArray(RED, i, 0);
			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			if(base.calculateDH(numOfDimOnBandD, numOfDimOnB)<=DHonR) {
				RED=B;
				labelOfNoRED = base.combineTwoArray(labelOfNoRED, base.splitArray(labelOfRED, i, 1));
				countOfNoRED++;
				labelOfRED=base.splitArray(labelOfRED, i, 0);
				countOfRED--;
				i=th-1;
			}
		}
		System.out.println("���յ�Լ�򼯺�RED����"+countOfRED+"������.�ֱ���");
		base.showArray(labelOfRED);
		

		//���Ӷ���

		long pre=System.currentTimeMillis();
		double[][] addSamples = dataProcess.getData(50);//��ȡʣ��50%�����ݵİٷֱ�
		double[][] universeSET = base.combineRow(universeSet, addSamples);
		double[][] addAttributeSet = base.splitBinaryArray(addSamples, P-1, 0);
		double[][] addDetermineSet = base.splitBinaryArray(addSamples, P-1, 1);
		int N1=addSamples.length;
		int NN = universeSET.length;
		double[][] addRED=base.splitBinaryArray(addAttributeSet, (int)labelOfRED[0], 1);
		for(i=1;i<countOfRED;i++) {
			addRED=base.combineColumn(addRED, base.splitBinaryArray(addAttributeSet, (int)labelOfRED[i], 1));
		}
		double[][] addNoRED = new double[N1][1];
		if(labelOfNoRED.length==0) ;			
		else
			addNoRED = base.splitBinaryArray(addAttributeSet, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			addNoRED = base.combineColumn(addNoRED, base.splitBinaryArray(addAttributeSet, (int)labelOfNoRED[i], 1));
		}
		double[][] adAttributeSet = base.splitBinaryArray(universeSET, P-1, 0);
		double[][] adRED=base.splitBinaryArray(adAttributeSet, (int)labelOfRED[0], 1);
		for(i=1;i<countOfRED;i++) {
			adRED=base.combineColumn(adRED, base.splitBinaryArray(adAttributeSet, (int)labelOfRED[i], 1));
		}
		double[][] adNoRED = new double[NN][1];
		if(labelOfNoRED.length==0) ;
		else
			adNoRED = base.splitBinaryArray(adAttributeSet, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			adNoRED = base.combineColumn(adNoRED, base.splitBinaryArray(adAttributeSet, (int)labelOfNoRED[i], 1));
		}
		
		double[][] rightupOFC = new double[N][N1];
		double[][] leftdownOFC = new double[N1][N];
		double[][] rightdownOFC = new double[N1][N1];
		for(i=0;i<N;i++) {
			for(j=0;j<N1;j++) {
				rightupOFC[i][j]=base.getDimananceRelation(base.getOnesample(allAttributeSet, i), base.getOnesample(addAttributeSet, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N;j++) {
				leftdownOFC[i][j]=base.getDimananceRelation(base.getOnesample(addAttributeSet, i), base.getOnesample(allAttributeSet, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N1;j++) {
				rightdownOFC[i][j]=base.getDimananceRelation(base.getOnesample(addAttributeSet, i), base.getOnesample(addAttributeSet, j));
			}
		}
		
		double[][] rightupOFD = new double[N][N1];
		double[][] leftdownOFD = new double[N1][N];
		double[][] rightdownOFD = new double[N1][N1];
		for(i=0;i<N;i++) {
			for(j=0;j<N1;j++) {
				rightupOFD[i][j]=base.getDimananceRelation(base.getOnesample(determineSet, i), base.getOnesample(addDetermineSet, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N;j++) {
				leftdownOFD[i][j]=base.getDimananceRelation(base.getOnesample(addDetermineSet, i), base.getOnesample(determineSet, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N1;j++) {
				rightdownOFD[i][j]=base.getDimananceRelation(base.getOnesample(addDetermineSet, i), base.getOnesample(addDetermineSet, j));
			}
		}
		
		double[][] rightupOFR = new double[N][N1];
		double[][] leftdownOFR = new double[N1][N];
		double[][] rightdownOFR = new double[N1][N1];
		for(i=0;i<N;i++) {
			for(j=0;j<N1;j++) {
				rightupOFR[i][j]=base.getDimananceRelation(base.getOnesample(RED, i), base.getOnesample(addRED, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N;j++) {
				leftdownOFR[i][j]=base.getDimananceRelation(base.getOnesample(addRED, i), base.getOnesample(RED, j));
			}
		}
		for(i=0;i<N1;i++) {
			for(j=0;j<N1;j++) {
				rightdownOFR[i][j]=base.getDimananceRelation(base.getOnesample(addRED, i), base.getOnesample(addRED, j));
			}
		}
		
		double[][] dMofaD = base.combineRow(base.combineColumn(dMofD, rightupOFD), base.combineColumn(leftdownOFD, rightdownOFD));			
		double[][] dMofaC = base.combineRow(base.combineColumn(dMofC, rightupOFC), base.combineColumn(leftdownOFC, rightdownOFC));
		double[][] dMofaCD = base.infTwoMetrix(dMofaC, dMofaD);
		double[] numOfDimOnaCD = base.calculateSumOfRow(dMofaCD);
		double[] numOfDimOnaC = base.calculateSumOfRow(dMofaC);
		double DHonaC=base.calculateDH(numOfDimOnaCD, numOfDimOnaC);
		
		System.out.println("�����������C�ϵ�������Ϊ��"+DHonaC);
		
		double[][] dMofaR = base.combineRow(base.combineColumn(dMofR, rightupOFR), base.combineColumn(leftdownOFR, rightdownOFR));
		double[][] dMofaRD = base.infTwoMetrix(dMofaR, dMofaD);
		double[] numOfDimOnaRD = base.calculateSumOfRow(dMofaRD);
		double[] numOfDimOnaR = base.calculateSumOfRow(dMofaR);
		double DHonaR=base.calculateDH(numOfDimOnaRD, numOfDimOnaR);
		System.out.println("�����������Լ��addRED�ϵ�������Ϊ��"+DHonaR);
		
		double[] sigOut1 = new double[countOfNoRED];
		for(i=0;i<countOfNoRED;i++) {
			double[][] B = base.combineColumn(adRED, base.splitBinaryArray(adNoRED, i, 1));	
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofaD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			sigOut1[i] = DHonaR-base.calculateDH(numOfDimOnBandD, numOfDimOnB);
		}
		System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
		base.showArray(sigOut1);
		
		while(DHonaR>DHonaC) {							
			int remember = 0;
			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut1[0];			
			for(i=0;i<countOfNoRED;i++) {
				if(maxSigOut<sigOut1[i]) {
					maxSigOut=sigOut1[i];
					remember = i;
				}
			}

			System.out.println("��"+(int)labelOfNoRED[remember]+"�����Է���Լ��addRED�С�");
			adRED = base.combineColumn(adRED, base.splitBinaryArray(adNoRED, remember, 1));
			labelOfRED = base.combineTwoArray(labelOfRED, base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;

			
			adNoRED = base.splitBinaryArray(adNoRED, remember, 0);
			labelOfNoRED = base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;		
			
			sigOut1 = base.splitArray(sigOut1, remember, 0);
			
			dMofR = base.establishDimananceMetrix(adRED);
			dMofRandD = base.infTwoMetrix(dMofR, dMofaD);
			numOfDimOnRandD = base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = base.calculateSumOfRow(dMofR);
			
			DHonaR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��"+DHonaR);
			
			if(DHonaR <= DHonaC) {
				System.out.println("Լ�򼯺�addRED����"+countOfRED+"�����ԡ��ֱ��ǣ�");
				base.showArray(labelOfRED);
			}
			if(countOfNoRED==0) {
				break;
			}			
		}
		
		//���Լ�򼯺�RED���Ƿ�����������
		System.out.println("");
		System.out.println("���Լ�򼯺�addRED���Ƿ�����������!");
		for(i=0;i<countOfRED;i++) {
			int th = i;
			double[][] B = base.splitBinaryArray(adRED, i, 0);				
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofaD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			if(base.calculateDH(numOfDimOnBandD, numOfDimOnB)<=DHonaR) {
				adRED=B;
				labelOfNoRED = base.combineTwoArray(labelOfNoRED, base.splitArray(labelOfRED, i, 1));
				countOfNoRED++;
				labelOfRED=base.splitArray(labelOfRED, i, 0);
				countOfRED--;
				i=th-1;
			}
		}
		
		System.out.println("���յ�Լ�򼯺�addRED����"+countOfRED+"������.�ֱ���");
		base.showArray(labelOfRED);
		long post=System.currentTimeMillis();
		System.out.println("test��������ʱ�䣺"+(post-pre)+"ms");
		

	}//main

}//��

