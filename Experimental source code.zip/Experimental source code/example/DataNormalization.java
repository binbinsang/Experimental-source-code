package example;

public class DataNormalization {

	public static double[][] ColumnNormalization(double[][] column) {
		int n = column.length;
		double max = column[0][0];
		double min = column[0][0];
		for(int i=0;i<n;i++) {
			if(max<column[i][0]) {
				max = column[i][0];
			}
			if(min>column[i][0]) {
				min = column[i][0];
			}
		}
		for(int i=0;i<n;i++) {
			column[i][0] = (column[i][0]-min)/(max-min);
		}
		
		return column;
	}
	
	public static double[][] MatrixNormalization(double[][] universiveSet) {
		int n = universiveSet.length, p = universiveSet[0].length;
		double[][] Normalized_universiveSet = new double[n][0];
		for(int j=0;j<p;j++) {
			double[][] column = base.splitBinaryArray(universiveSet, j, 1);
			column = ColumnNormalization(column);
			Normalized_universiveSet = base.combineColumn(Normalized_universiveSet, column);
		}
		return Normalized_universiveSet;
	}
}
