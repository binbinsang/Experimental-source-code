package example;

import java.io.File;
import java.io.IOException;

import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ArffSaver;
public class instanceReader {
	
	public static Instances readData(File inputFile) throws IOException{
		
		ArffLoader atf = new ArffLoader();
        atf.setFile(inputFile);
        //���������ļ�
        Instances instance = atf.getDataSet();        
		return instance;
	}
	
	public static double[][] getAllData() throws Exception {
		File inputFile = new File("instance\\example.arff");  
        Instances instances = readData(inputFile);
		 int n = instances.numInstances();
         int p = instances.numAttributes();
         double[][] universeSet = new double[n][p];
         for(int i=0;i<n;i++) {
        	 for(int j=0;j<p;j++) {
        		universeSet[i][j]=instances.instance(i).value(j); 
        	 }
         }
         return universeSet;
	}
	
    public static void main(String[] args) throws Exception  {
    	double[][] test = getAllData();  
    	System.out.println(test[0].length-1);
//        base.showBinaryArray(universeSet);
    }
}

