package example;

public class Improv2Increase {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		long pre=System.currentTimeMillis();
		double[][] universeSet1 = dataProcess.getPrio50Data();
		double[][] addsample = dataProcess.getData(50);//��õ�ʣ��50%�����ݵİٷֱ�
		double[][] universeSet = base.combineRow(universeSet1, addsample);
		int i=0;
		int N=universeSet.length, P=universeSet[0].length;
		double[][] allAttributeSet = base.splitBinaryArray(universeSet, P-1, 0);
		double[][] determineSet = base.splitBinaryArray(universeSet, P-1, 1);

		
		double[][] dMofD = base.establishDimananceMetrix(determineSet);
		double[][] dMofC = base.establishDimananceMetrix(allAttributeSet);
		double[][] dMofCD = base.infTwoMetrix(dMofC, dMofD);
		double[] numOfDimOnCandD = base.calculateSumOfRow(dMofCD);
		double[] numOfDimOnC = base.calculateSumOfRow(dMofC);
		double DHonC=base.calculateDH(numOfDimOnCandD, numOfDimOnC);
		
		System.out.println("���������������Լ�C�;������Լ�D�ϵ����������Ϊ��");
		base.showArray(numOfDimOnCandD);
		System.out.println("���������������Լ�C�ϵ����������Ϊ��");
		base.showArray(numOfDimOnC);
		System.out.println("���������Լ�C�ϵ�����������Ϊ��");
		System.out.println(DHonC);
		
		double[] sigInner = new double[P-1];
		for(i=0;i<P-1;i++) {
			double[][] B = base.splitBinaryArray(allAttributeSet, i, 0);
			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			sigInner[i] = base.calculateDH(numOfDimOnBandD, numOfDimOnB)-DHonC;
			System.out.println("��"+i+"�����Ե�����Ҫ��Ϊ��"+sigInner[i]);
		}
		
		int countOfRED = 0;
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				countOfRED++;
			}
		}
		int countOfNoRED = P-1-countOfRED;
		int t1=0,t2=0;
		double[] labelOfRED = new double[countOfRED];
		double[] labelOfNoRED = new double[countOfNoRED];
		for(i=0;i<P-1;i++) {
			if(sigInner[i]>0) {
				labelOfRED[t1]=i;
				t1++;
			}
			else {
				labelOfNoRED[t2]=i;
				t2++;
			}
		}
		double[][] RED = new double[2][2];
		if(labelOfRED.length==0) {
			double[] hyber = new double[1];
			hyber[0]=0;
			RED = base.splitBinaryArray(allAttributeSet, 0, 1);
			countOfRED++;
			labelOfRED=base.combineTwoArray(labelOfRED, hyber);
			labelOfNoRED=base.splitArray(labelOfNoRED, 0, 0);
			countOfNoRED--;
		}
		else
			RED = base.splitBinaryArray(allAttributeSet, (int)labelOfRED[0], 1);
		base.showArray(labelOfRED);
		base.showArray(labelOfNoRED);
		for(i=1;i<countOfRED;i++) {
			RED = base.combineColumn(RED, base.splitBinaryArray(allAttributeSet, (int)labelOfRED[i], 1));
		}
		double[][] noRED = new double[N][1];
		if(labelOfNoRED.length==0) 
			;
		else
			noRED = base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[0], 1);
		for(i=1;i<countOfNoRED;i++) {
			noRED = base.combineColumn(noRED, base.splitBinaryArray(allAttributeSet, (int)labelOfNoRED[i], 1));
		}
		
		double[][] dMofR = base.establishDimananceMetrix(RED);
		double[][] dMofRandD = base.infTwoMetrix(dMofR, dMofD);
		double[] numOfDimOnRandD = base.calculateSumOfRow(dMofRandD);
		double[] numOfDimOnR = base.calculateSumOfRow(dMofR);
		double DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
		
		System.out.println("������Ҫ�ȵó���Լ��RED�ϵ�������Ϊ��"+DHonR);
//		double[] sigOut = new double[countOfNoRED];
//		for(i=0;i<countOfNoRED;i++) {
//			double[][] B = base.combineColumn(RED, base.splitBinaryArray(noRED, i, 1));
//			double[][] dMofB = base.establishDimananceMetrix(B);
//			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
//			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
//			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
//			sigOut[i] = base.calculateDH(numOfDimOnBandD, numOfDimOnB)-DHonR;
//		}
//		System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
//		base.showArray(sigOut);
		while(DHonR>DHonC) {
			double[] sigOut = new double[countOfNoRED];
			for(i=0;i<countOfNoRED;i++) {
				double[][] B = base.combineColumn(RED, base.splitBinaryArray(noRED, i, 1));
//				double[][] BandD = base.combineColumn(B, determineSet);
				
				double[][] dMofB = base.establishDimananceMetrix(B);
				double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
				sigOut[i] =DHonR-base.calculateDH(numOfDimOnBandD, numOfDimOnB);//�޸Ĺ�by sang
			}
			System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
			base.showArray(sigOut);
			int remember = 0;
			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut[0];			
			for(i=0;i<countOfNoRED;i++) {
				if(maxSigOut<sigOut[i]) {
					maxSigOut=sigOut[i];
					remember = i;
				}
			}
			
			System.out.println("��"+(int)labelOfNoRED[remember]+"�����Է���Լ��RED�С�");
			RED = base.combineColumn(RED, base.splitBinaryArray(noRED, remember, 1));
			labelOfRED = base.combineTwoArray(labelOfRED, base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;
			
			noRED = base.splitBinaryArray(noRED, remember, 0);
			labelOfNoRED = base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;
			
			sigOut = base.splitArray(sigOut, remember, 0);
			
			if(countOfNoRED==-1) {
				System.out.println("�����ˣ�����");
				break;
			}
			
			dMofR = base.establishDimananceMetrix(RED);
			dMofRandD = base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = base.calculateSumOfRow(dMofR);
			
			DHonR = base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��"+DHonR);
			
			if(DHonR <= DHonC) {
				System.out.println("Լ�򼯺�RED����"+countOfRED+"�����ԡ��ֱ��ǣ�");
				base.showArray(labelOfRED);
				break;
			}						
		}	
		//���Լ�򼯺�RED���Ƿ�����������
		System.out.println("");
		System.out.println("���Լ�򼯺�RED���Ƿ�����������!");
		for(i=0;i<countOfRED;i++) {
			int th =i;
			double[][] B = base.splitBinaryArray(RED, i, 0);
//			double[][] BandD = base.combineColumn(B, determineSet);
			
			double[][] dMofB = base.establishDimananceMetrix(B);
			double[][] dMofBandD = base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = base.calculateSumOfRow(dMofB);
			if(base.calculateDH(numOfDimOnBandD, numOfDimOnB)<=DHonR) {
				RED=B;
				
				labelOfNoRED = base.combineTwoArray(labelOfNoRED, base.splitArray(labelOfRED, i, 1));
				countOfNoRED++;
				labelOfRED=base.splitArray(labelOfRED, i, 0);
				countOfRED--;
				i=th-1;
			}
		}
		System.out.println("���յ�Լ�򼯺�RED����"+countOfRED+"������.�ֱ���");
		base.showArray(labelOfRED);
		
	
		long post=System.currentTimeMillis();
		System.out.println("��������ʱ�䣺"+(post-pre)+"ms");	
	}//main
}//��
