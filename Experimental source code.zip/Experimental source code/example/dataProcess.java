package example;

public class dataProcess {

	
	public static double[][] getPrio50Data() throws Exception{
		double[][] universeSet = instanceReader.getAllData();
		int N = universeSet.length, P=universeSet[0].length;
		int N1=N/2;
		double[][] halfU = new double[N1][P];
		for(int i=0;i<N1;i++) {
			for(int j=0;j<P;j++) {
				halfU[i][j] = universeSet[i][j];
			}
		}
		return halfU;
	}
	
	public static double[][] getData(double percentage) throws Exception{
		double[][] universeSet = instanceReader.getAllData();
		int N = universeSet.length, P=universeSet[0].length;
		double N1=N*percentage/100;
		double[][] partU = new double[(int) N1][P];
		for(int i=0;i<(int)N1;i++) {
			for(int j=0;j<P;j++) {
				partU[i][j] = universeSet[(int) (i+N*0.5)][j];
			}
		}
		return partU;
	}
	public static double[][] getPercentData(int percentage) throws Exception{
		double[][] universeSet = instanceReader.getAllData();
		int N = universeSet.length, P=universeSet[0].length;
		int N1=N*percentage/100;
		double[][] partUniverseSet = new double[N1][P];
		for(int i=0;i<N1;i++) {
			for(int j=0;j<P;j++) {
				partUniverseSet[i][j] = universeSet[i][j];
			}
		}
		return partUniverseSet;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
