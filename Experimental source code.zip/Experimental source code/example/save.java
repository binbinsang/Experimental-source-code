package example;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
public class save {	
	    public static void write(long time) throws IOException {
	        
	        FileOutputStream fileOutputStream = null;
	        File file = new File("result\\time.txt");
	        if(!file.exists()){
	            file.createNewFile();
	        }
	        fileOutputStream = new FileOutputStream(file);
	        fileOutputStream.write((int) time);
	        fileOutputStream.flush();
	        fileOutputStream.close();
	    }
}
