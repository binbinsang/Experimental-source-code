package interval;

public class Interval {

	public static double[][] interval(double[][] attribute) {

		int n = attribute.length, p = attribute[0].length;

		double[][] result = new double[n][2 * p];

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < p - 1; j++) {
				result[i][2 * j] = attribute[i][j] * 0.95;

				result[i][2 * j + 1] = attribute[i][j] * 1.05;
			}
		}

		return result;

	}

}
