package interval.Fuz;

public class FuzDominanceMatrix {

	public static double[][] fuzInterval(double[][] attribute) {

		int N = attribute.length;

		// ���ģ�����ƾ���
		double[][] fuzDomMatrix = new double[N][N];

		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				fuzDomMatrix[i][j] = intervalDominance(attribute, i, j);
			}
		}

		return fuzDomMatrix;
	}

	private static double intervalDominance(double[][] attribute, int i, int j) {
		// TODO Auto-generated method stub

		int P = attribute[0].length;
		int L = P / 2;

		double[] resultL = new double[L];
		double[] resultR = new double[L];

		double[] result = new double[L];

		int m = 0, n = 0;

		for (int k = 0; k < P; k++) {

			if (k % 2 == 0) {
				resultL[m] = 1 / (1 + exp(-2 * (attribute[i][k] - attribute[j][k])));
				m++;
			}

		}
		
		for (int t = 0; t < L; t++) {
			if (resultL[t] > 0.45 && resultL[t] < 0.55)// ��ֵ�ж�
				resultL[t] = 0.5;
		}
		
		for (int k = 0; k < P; k++) {
			if (k % 2 != 0) {
				resultR[n] = 1 / (1 + exp(-2 * (attribute[i][k] - attribute[j][k])));
				n++;
			}
		}
		
		for (int t = 0; t < L; t++) {
			if (resultR[t] > 0.45 && resultR[t] < 0.55)// ��ֵ�ж�
				resultR[t] = 0.5;
		}

		for (int k = 0; k < L; k++) {
			result[k] = 0.5 * (resultL[k] + resultR[k]);
		}

//		for (int k = 0; k < L; k++) {
//			if (result[k] > 0.45 && result[k] < 0.55)//��ֵ�ж�
//				result[k] = 0.5;
//		}

		double min = -1;
		for (int k = 0; k < L; k++) {
			if (result[k] > min)
				min = result[k];
		}

		return min;
	}

	private static double exp(double exponent) {

		return Math.pow(Math.E, exponent);

	}

}
