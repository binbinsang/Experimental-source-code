package interval.Tra;

import interval.ArffReader;
import interval.Base;
import interval.Interval;
import interval.Normal;

public class InterDomARIncr {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		double[][] universeSet = ArffReader.getPercentArffData(0, 50);
		int i = 0, j = 0;
		int N = universeSet.length, P = universeSet[0].length;
		double[][] allAttribute = Base.splitBinaryArray(universeSet, P - 1, 0);
		Normal.normal(allAttribute);
		double[][] attribute = Interval.interval(allAttribute);

		double[][] determine = Base.splitBinaryArray(universeSet, P - 1, 1);

		double[][] dMofD = Base.estabDomMatrix(determine);
		double[][] dMofC = Base.estabDomMatrix(attribute);
		double[][] dMofCD = Base.infTwoMetrix(dMofC, dMofD);
		double[] numOfDimOnCandD = Base.calculateSumOfRow(dMofCD);
		double[] numOfDimOnC = Base.calculateSumOfRow(dMofC);
		double DHonC = Base.calculateDH(numOfDimOnCandD, numOfDimOnC);

		System.out.println("���������������Լ�C�;������Լ�D�ϵ����������Ϊ��");
		Base.showArray(numOfDimOnCandD);
		System.out.println("���������������Լ�C�ϵ����������Ϊ��");
		Base.showArray(numOfDimOnC);
		System.out.println("���������Լ�C�ϵ�����������Ϊ��");
		System.out.println(DHonC);

		double[] sigInner = new double[P - 1];
		for (i = 0; i < P - 1; i++) {
			double[][] B1 = Base.splitBinaryArray(allAttribute, i, 0);

			double[][] B = Interval.interval(B1);
			double[][] dMofB = Base.estabDomMatrix(B);
			double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
			sigInner[i] = Base.calculateDH(numOfDimOnBandD, numOfDimOnB) - DHonC;
			System.out.println("��" + i + "�����Ե�����Ҫ��Ϊ��" + sigInner[i]);
		}

		int countOfRED = 0;
		for (i = 0; i < P - 1; i++) {
			if (sigInner[i] > 0) {
				countOfRED++;
			}
		}
		int countOfNoRED = P - 1 - countOfRED;
		int t1 = 0, t2 = 0;
		double[] labelOfRED = new double[countOfRED];
		double[] labelOfNoRED = new double[countOfNoRED];
		for (i = 0; i < P - 1; i++) {
			if (sigInner[i] > 0) {
				labelOfRED[t1] = i;
				t1++;
			} else {
				labelOfNoRED[t2] = i;
				t2++;
			}
		}

		double[][] RED = new double[2][2];
		if (labelOfRED.length == 0) {
			double[] hyber = new double[1];
			hyber[0] = 0;
			RED = Base.splitBinaryArray(allAttribute, 0, 1);
			countOfRED++;
			labelOfRED = Base.combineTwoArray(labelOfRED, hyber);
			labelOfNoRED = Base.splitArray(labelOfNoRED, 0, 0);
			countOfNoRED--;
		} else
			RED = Base.splitBinaryArray(allAttribute, (int) labelOfRED[0], 1);
		for (i = 1; i < countOfRED; i++) {
			RED = Base.combineColumn(RED, Base.splitBinaryArray(allAttribute, (int) labelOfRED[i], 1));
		}
		double[][] noRED = new double[N][1];
		if (labelOfNoRED.length == 0)
			;
		else
			noRED = Base.splitBinaryArray(allAttribute, (int) labelOfNoRED[0], 1);
		for (i = 1; i < countOfNoRED; i++) {
			noRED = Base.combineColumn(noRED, Base.splitBinaryArray(allAttribute, (int) labelOfNoRED[i], 1));
		}

		double[][] RED1 = Interval.interval(RED);

		double[][] dMofR = Base.estabDomMatrix(RED1);
		double[][] dMofRandD = Base.infTwoMetrix(dMofR, dMofD);
		double[] numOfDimOnRandD = Base.calculateSumOfRow(dMofRandD);
		double[] numOfDimOnR = Base.calculateSumOfRow(dMofR);
		double DHonR = Base.calculateDH(numOfDimOnRandD, numOfDimOnR);

		System.out.println("������Ҫ�ȵó���Լ��RED�ϵ�������Ϊ��" + DHonR);

		while (DHonR > DHonC) {
			double[] sigOut = new double[countOfNoRED];
			for (i = 0; i < countOfNoRED; i++) {
				double[][] B1 = Base.combineColumn(RED, Base.splitBinaryArray(noRED, i, 1));

				double[][] B = Interval.interval(B1);

				double[][] dMofB = Base.estabDomMatrix(B);
				double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
				sigOut[i] = DHonR - Base.calculateDH(numOfDimOnBandD, numOfDimOnB);
			}
			System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
			Base.showArray(sigOut);
			int remember = 0;

			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut[0];
			for (i = 0; i < countOfNoRED; i++) {
				if (maxSigOut < sigOut[i]) {
					maxSigOut = sigOut[i];
					remember = i;
				}
			}

			System.out.println("��" + (int) labelOfNoRED[remember] + "�����Է���Լ��RED�С�");
			RED = Base.combineColumn(RED, Base.splitBinaryArray(noRED, remember, 1));
			labelOfRED = Base.combineTwoArray(labelOfRED, Base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;

			noRED = Base.splitBinaryArray(noRED, remember, 0);
			labelOfNoRED = Base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;
			if (countOfNoRED == -1) {
				System.out.println("�����ˣ�����");
				break;
			}
			sigOut = Base.splitArray(sigOut, remember, 0);

			RED1 = Interval.interval(RED);

			dMofR = Base.estabDomMatrix(RED1);
			dMofRandD = Base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = Base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = Base.calculateSumOfRow(dMofR);

			DHonR = Base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��" + DHonR);

			if (DHonR <= DHonC) {
				System.out.println("Լ�򼯺�RED����" + countOfRED + "�����ԡ��ֱ��ǣ�");
				Base.showArray(labelOfRED);
				break;
			}

		}

		if (labelOfRED.length != 1) {
			// ���Լ�򼯺�RED���Ƿ�����������
			System.out.println("");
			System.out.println("���Լ�򼯺�RED���Ƿ�����������!");
			for (i = 0; i < countOfRED; i++) {
				int th = i;
				double[][] B1 = Base.splitBinaryArray(RED, i, 0);

				double[][] B = Interval.interval(B1);

				double[][] dMofB = Base.estabDomMatrix(B);
				double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
				if (labelOfRED.length != 1) {
				if (Base.calculateDH(numOfDimOnBandD, numOfDimOnB) <= DHonR) {
					RED = B;
					labelOfNoRED = Base.combineTwoArray(labelOfNoRED, Base.splitArray(labelOfRED, i, 1));
					countOfNoRED++;
					labelOfRED = Base.splitArray(labelOfRED, i, 0);
					countOfRED--;
					i = th - 1;
				}
				}
			}
		}
		System.out.println("���յ�Լ�򼯺�RED����" + countOfRED + "������.�ֱ���");
		Base.showArray(labelOfRED);

		// ���Ӷ���
		long pre = System.currentTimeMillis();
		double[][] addSamples = ArffReader.getPercentArffData(50, 100);// ��ȡʣ��50%�����ݵİٷֱ�
		double[][] universeSET = Base.combineRow(universeSet, addSamples);
		double[][] addAttributeSet = Base.splitBinaryArray(addSamples, P - 1, 0);
		Normal.normal(addAttributeSet);
		double[][] attribute1 = Interval.interval(addAttributeSet);

		double[][] addDetermineSet = Base.splitBinaryArray(addSamples, P - 1, 1);
		int N1 = addSamples.length;
		int NN = universeSET.length;
		double[][] addRED = Base.splitBinaryArray(addAttributeSet, (int) labelOfRED[0], 1);
		for (i = 1; i < countOfRED; i++) {
			addRED = Base.combineColumn(addRED, Base.splitBinaryArray(addAttributeSet, (int) labelOfRED[i], 1));
		}
		double[][] addNoRED = new double[N1][1];
		if (labelOfNoRED.length == 0)
			;
		else
			addNoRED = Base.splitBinaryArray(addAttributeSet, (int) labelOfNoRED[0], 1);
		for (i = 1; i < countOfNoRED; i++) {
			addNoRED = Base.combineColumn(addNoRED, Base.splitBinaryArray(addAttributeSet, (int) labelOfNoRED[i], 1));
		}
		double[][] adAttributeSet = Base.splitBinaryArray(universeSET, P - 1, 0);
		double[][] adRED = Base.splitBinaryArray(adAttributeSet, (int) labelOfRED[0], 1);
		for (i = 1; i < countOfRED; i++) {
			adRED = Base.combineColumn(adRED, Base.splitBinaryArray(adAttributeSet, (int) labelOfRED[i], 1));
		}
		double[][] adNoRED = new double[NN][1];
		if (labelOfNoRED.length == 0)
			;
		else
			adNoRED = Base.splitBinaryArray(adAttributeSet, (int) labelOfNoRED[0], 1);
		for (i = 1; i < countOfNoRED; i++) {
			adNoRED = Base.combineColumn(adNoRED, Base.splitBinaryArray(adAttributeSet, (int) labelOfNoRED[i], 1));
		}

		double[][] C1 = new double[N][N1];
		double[][] C2 = new double[N1][N];
		double[][] C3 = new double[N1][N1];
		for (i = 0; i < N; i++) {
			for (j = 0; j < N1; j++) {
				C1[i][j] = Base.compDomRelation(Base.getOnesample(attribute, i), Base.getOnesample(attribute1, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N; j++) {
				C2[i][j] = Base.compDomRelation(Base.getOnesample(attribute1, i), Base.getOnesample(attribute, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N1; j++) {
				C3[i][j] = Base.compDomRelation(Base.getOnesample(attribute1, i), Base.getOnesample(attribute1, j));
			}
		}

		double[][] D1 = new double[N][N1];
		double[][] D2 = new double[N1][N];
		double[][] D3 = new double[N1][N1];
		for (i = 0; i < N; i++) {
			for (j = 0; j < N1; j++) {
				D1[i][j] = Base.compDomRelation(Base.getOnesample(determine, i), Base.getOnesample(addDetermineSet, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N; j++) {
				D2[i][j] = Base.compDomRelation(Base.getOnesample(addDetermineSet, i), Base.getOnesample(determine, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N1; j++) {
				D3[i][j] = Base.compDomRelation(Base.getOnesample(addDetermineSet, i),
						Base.getOnesample(addDetermineSet, j));
			}
		}

		double[][] RED2 = Interval.interval(RED);
		double[][] addRED2 = Interval.interval(addRED);

		double[][] R1 = new double[N][N1];
		double[][] R2 = new double[N1][N];
		double[][] R3 = new double[N1][N1];
		for (i = 0; i < N; i++) {
			for (j = 0; j < N1; j++) {
				R1[i][j] = Base.compDomRelation(Base.getOnesample(RED2, i), Base.getOnesample(addRED2, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N; j++) {
				R2[i][j] = Base.compDomRelation(Base.getOnesample(addRED2, i), Base.getOnesample(RED2, j));
			}
		}
		for (i = 0; i < N1; i++) {
			for (j = 0; j < N1; j++) {
				R3[i][j] = Base.compDomRelation(Base.getOnesample(addRED2, i), Base.getOnesample(addRED2, j));
			}
		}

		double[][] dMofaD = Base.combineRow(Base.combineColumn(dMofD, D1), Base.combineColumn(D2, D3));
		double[][] dMofaC = Base.combineRow(Base.combineColumn(dMofC, C1), Base.combineColumn(C2, C3));
		double[][] dMofaCD = Base.infTwoMetrix(dMofaC, dMofaD);
		double[] numOfDimOnaCD = Base.calculateSumOfRow(dMofaCD);
		double[] numOfDimOnaC = Base.calculateSumOfRow(dMofaC);
		double DHonaC = Base.calculateDH(numOfDimOnaCD, numOfDimOnaC);

		System.out.println("�����������C�ϵ�������Ϊ��" + DHonaC);

		double[][] dMofaR = Base.combineRow(Base.combineColumn(dMofR, R1), Base.combineColumn(R2, R3));
		double[][] dMofaRD = Base.infTwoMetrix(dMofaR, dMofaD);
		double[] numOfDimOnaRD = Base.calculateSumOfRow(dMofaRD);
		double[] numOfDimOnaR = Base.calculateSumOfRow(dMofaR);
		double DHonaR = Base.calculateDH(numOfDimOnaRD, numOfDimOnaR);
		System.out.println("�����������Լ��addRED�ϵ�������Ϊ��" + DHonaR);

		double[] sigOut1 = new double[countOfNoRED];
		for (i = 0; i < countOfNoRED; i++) {
			double[][] B1 = Base.combineColumn(adRED, Base.splitBinaryArray(adNoRED, i, 1));

			double[][] B = Interval.interval(B1);

			double[][] dMofB = Base.estabDomMatrix(B);
			double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofaD);
			double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
			sigOut1[i] = DHonaR - Base.calculateDH(numOfDimOnBandD, numOfDimOnB);
		}
		System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
		Base.showArray(sigOut1);

		while (DHonaR > DHonaC) {
			int remember = 0;
			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut1[0];
			for (i = 0; i < countOfNoRED; i++) {
				if (maxSigOut < sigOut1[i]) {
					maxSigOut = sigOut1[i];
					remember = i;
				}
			}

			System.out.println("��" + (int) labelOfNoRED[remember] + "�����Է���Լ��addRED�С�");
			adRED = Base.combineColumn(adRED, Base.splitBinaryArray(adNoRED, remember, 1));
			labelOfRED = Base.combineTwoArray(labelOfRED, Base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;

			adNoRED = Base.splitBinaryArray(adNoRED, remember, 0);
			labelOfNoRED = Base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;

			sigOut1 = Base.splitArray(sigOut1, remember, 0);

			dMofR = Base.estabDomMatrix(adRED);
			dMofRandD = Base.infTwoMetrix(dMofR, dMofaD);
			numOfDimOnRandD = Base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = Base.calculateSumOfRow(dMofR);

			DHonaR = Base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��" + DHonaR);

			if (DHonaR <= DHonaC) {
				System.out.println("Լ�򼯺�addRED����" + countOfRED + "�����ԡ��ֱ��ǣ�");
				Base.showArray(labelOfRED);
			}
			if (countOfNoRED == 0) {
				break;
			}
		}

		if (labelOfRED.length != 1) {

			// ���Լ�򼯺�RED���Ƿ�����������
			System.out.println("");
			System.out.println("���Լ�򼯺�addRED���Ƿ�����������!");
			for (i = 0; i < countOfRED; i++) {
				int th = i;
				double[][] B = Base.splitBinaryArray(adRED, i, 0);
				double[][] dMofB = Base.estabDomMatrix(B);
				double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofaD);
				double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
				if (labelOfRED.length != 1) {
				if (Base.calculateDH(numOfDimOnBandD, numOfDimOnB) <= DHonaR) {
					adRED = B;
					labelOfNoRED = Base.combineTwoArray(labelOfNoRED, Base.splitArray(labelOfRED, i, 1));
					countOfNoRED++;
					labelOfRED = Base.splitArray(labelOfRED, i, 0);
					countOfRED--;
					i = th - 1;
				}
				}
			}
		}
		System.out.println("���յ�Լ�򼯺�addRED����" + countOfRED + "������.�ֱ���");
		Base.showArray(labelOfRED);
		long post = System.currentTimeMillis();
		System.out.println("test��������ʱ�䣺" + (post - pre) + "ms");

	}// main

}// ��
