package interval.Tra;

import interval.ArffReader;
import interval.Base;
import interval.Interval;
import interval.Normal;

public class InterDomARRed {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		long pre = System.currentTimeMillis();

		double[][] universeSet = ArffReader.getPercentArffData(0, 90);// ��ȡ����İٷֱ�
		int i = 0;
		int N = universeSet.length, P = universeSet[0].length;
		double[][] allAttribute = Base.splitBinaryArray(universeSet, P - 1, 0);
		Normal.normal(allAttribute);
		double[][] attribute = Interval.interval(allAttribute);

		double[][] determine = Base.splitBinaryArray(universeSet, P - 1, 1);

		double[][] dMofD = Base.estabDomMatrix(determine);
		double[][] dMofC = Base.estabDomMatrix(attribute);
		double[][] dMofCD = Base.infTwoMetrix(dMofC, dMofD);
		double[] numOfDimOnCandD = Base.calculateSumOfRow(dMofCD);
		double[] numOfDimOnC = Base.calculateSumOfRow(dMofC);
		double DHonC = Base.calculateDH(numOfDimOnCandD, numOfDimOnC);

		System.out.println("���������������Լ�C�;������Լ�D�ϵ����������Ϊ��");
		Base.showArray(numOfDimOnCandD);
		System.out.println("���������������Լ�C�ϵ����������Ϊ��");
		Base.showArray(numOfDimOnC);
		System.out.println("���������Լ�C�ϵ�����������Ϊ��");
		System.out.println(DHonC);

		double[] sigInner = new double[P - 1];
		for (i = 0; i < P - 1; i++) {
			double[][] B = Base.splitBinaryArray(attribute, i, 0);
			double[][] dMofB = Base.estabDomMatrix(B);
			double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
			double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
			double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
			sigInner[i] = Base.calculateDH(numOfDimOnBandD, numOfDimOnB) - DHonC;
			System.out.println("��" + i + "�����Ե�����Ҫ��Ϊ��" + sigInner[i]);
		}

		int countOfRED = 0;
		for (i = 0; i < P - 1; i++) {
			if (sigInner[i] > 0) {
				countOfRED++;
			}
		}
		int countOfNoRED = P - 1 - countOfRED;
		int t1 = 0, t2 = 0;
		double[] labelOfRED = new double[countOfRED];
		double[] labelOfNoRED = new double[countOfNoRED];
		for (i = 0; i < P - 1; i++) {
			if (sigInner[i] > 0) {
				labelOfRED[t1] = i;
				t1++;
			} else {
				labelOfNoRED[t2] = i;
				t2++;
			}
		}
		double[][] RED = new double[2][2];
		if (labelOfRED.length == 0) {
			double[] hyber = new double[1];
			hyber[0] = 0;
			RED = Base.splitBinaryArray(allAttribute, 0, 1);
			countOfRED++;
			labelOfRED = Base.combineTwoArray(labelOfRED, hyber);
			labelOfNoRED = Base.splitArray(labelOfNoRED, 0, 0);
			countOfNoRED--;
		} else
			RED = Base.splitBinaryArray(allAttribute, (int) labelOfRED[0], 1);
		Base.showArray(labelOfRED);
		Base.showArray(labelOfNoRED);
		for (i = 1; i < countOfRED; i++) {
			RED = Base.combineColumn(RED, Base.splitBinaryArray(allAttribute, (int) labelOfRED[i], 1));
		}
		double[][] noRED = new double[N][1];
		if (labelOfNoRED.length == 0)
			;
		else
			noRED = Base.splitBinaryArray(allAttribute, (int) labelOfNoRED[0], 1);
		for (i = 1; i < countOfNoRED; i++) {
			noRED = Base.combineColumn(noRED, Base.splitBinaryArray(allAttribute, (int) labelOfNoRED[i], 1));
		}

		double[][] RED_Inter = Interval.interval(RED);

		double[][] dMofR = Base.estabDomMatrix(RED_Inter);
		double[][] dMofRandD = Base.infTwoMetrix(dMofR, dMofD);
		double[] numOfDimOnRandD = Base.calculateSumOfRow(dMofRandD);
		double[] numOfDimOnR = Base.calculateSumOfRow(dMofR);
		double DHonR = Base.calculateDH(numOfDimOnRandD, numOfDimOnR);

		System.out.println("������Ҫ�ȵó���Լ��RED�ϵ�������Ϊ��" + DHonR);

		while (DHonR > DHonC) {

			double[] sigOut = new double[countOfNoRED];
			for (i = 0; i < countOfNoRED; i++) {
				double[][] B = Base.combineColumn(RED, Base.splitBinaryArray(noRED, i, 1));

				double[][] B_Inter = Interval.interval(B);

				double[][] dMofB = Base.estabDomMatrix(B_Inter);
				double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
				sigOut[i] = DHonR - Base.calculateDH(numOfDimOnBandD, numOfDimOnB);
			}
			System.out.println("ʣ������Ե�����Ҫ��Ϊ��");
			Base.showArray(sigOut);
			int remember = 0;
			System.out.println("�ں��ϵ���С�������Լ��ϵ��أ�");
			double maxSigOut = sigOut[0];
			for (i = 0; i < countOfNoRED; i++) {
				if (maxSigOut < sigOut[i]) {
					maxSigOut = sigOut[i];
					remember = i;
				}
			}
			System.out.println("��" + (int) labelOfNoRED[remember] + "�����Է���Լ��RED�С�");
			RED = Base.combineColumn(RED, Base.splitBinaryArray(noRED, remember, 1));
			labelOfRED = Base.combineTwoArray(labelOfRED, Base.splitArray(labelOfNoRED, remember, 1));
			countOfRED++;

			noRED = Base.splitBinaryArray(noRED, remember, 0);
			labelOfNoRED = Base.splitArray(labelOfNoRED, remember, 0);
			countOfNoRED--;
			if (countOfNoRED == -1) {
				System.out.println("�����ˣ�����");
				break;
			}

			sigOut = Base.splitArray(sigOut, remember, 0);

			RED_Inter = Interval.interval(RED);

			dMofR = Base.estabDomMatrix(RED_Inter);
			dMofRandD = Base.infTwoMetrix(dMofR, dMofD);
			numOfDimOnRandD = Base.calculateSumOfRow(dMofRandD);
			numOfDimOnR = Base.calculateSumOfRow(dMofR);

			DHonR = Base.calculateDH(numOfDimOnRandD, numOfDimOnR);
			System.out.println("��ʱ��������Ϊ��" + DHonR);

			if (DHonR <= DHonC) {
				System.out.println("Լ�򼯺�RED����" + countOfRED + "�����ԡ��ֱ��ǣ�");
				Base.showArray(labelOfRED);
				break;
			}

		}

		if (labelOfRED.length != 1) {

			// ���Լ�򼯺�RED���Ƿ�����������
			System.out.println("");
			System.out.println("���Լ�򼯺�RED���Ƿ�����������!");
			for (i = 0; i < countOfRED; i++) {
				int th = i;
				double[][] B = Base.splitBinaryArray(RED, i, 0);

				double[][] B_Inter = Interval.interval(B);

				double[][] dMofB = Base.estabDomMatrix(B_Inter);
				double[][] dMofBandD = Base.infTwoMetrix(dMofB, dMofD);
				double[] numOfDimOnBandD = Base.calculateSumOfRow(dMofBandD);
				double[] numOfDimOnB = Base.calculateSumOfRow(dMofB);
				if (Base.calculateDH(numOfDimOnBandD, numOfDimOnB) <= DHonR) {
					RED = B;

					labelOfNoRED = Base.combineTwoArray(labelOfNoRED, Base.splitArray(labelOfRED, i, 1));
					countOfNoRED++;
					labelOfRED = Base.splitArray(labelOfRED, i, 0);
					countOfRED--;
					i = th - 1;
				}
			}
		}
		System.out.println("���յ�Լ�򼯺�RED����" + countOfRED + "������.�ֱ���");
		Base.showArray(labelOfRED);

		long post = System.currentTimeMillis();
		System.out.println("��������ʱ�䣺" + (post - pre) + "ms");
	}// main
}// ��
