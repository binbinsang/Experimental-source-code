package interval;

import java.io.File;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
public class ArffReader {
	public static double[][] getPercentArffData(int begins, int ends) throws Exception {
		String inputFilePath = "instance/Hous.arff";
		File input = new File(inputFilePath);
		ArffLoader arf = new ArffLoader();
        arf.setFile(input);
        Instances instances = arf.getDataSet();		  
		int N = instances.numInstances();
        int P = instances.numAttributes();
        
        int beginss = N*begins/100, endss = N*ends/100;
		double[][] partUniverseSet = new double[endss-beginss][P];
		for(int i=beginss;i<endss;i++) {
			for(int j=0;j<P;j++) {
				partUniverseSet[i-beginss][j] = instances.instance(i).value(j);
			}
		}
		return partUniverseSet;
	}

}

