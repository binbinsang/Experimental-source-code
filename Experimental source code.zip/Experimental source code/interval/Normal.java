package interval;

public class Normal {

	public static void normal(double[][] attribute) {

		int n = attribute.length, p = attribute[0].length;

		for (int j = 0; j < p; j++) {

			double max = attribute[0][j];
			double min = attribute[0][j];

			for (int i = 1; i < n; i++) {
				if (attribute[i][j] > max)
					max = attribute[i][j];
				if (attribute[i][j] < min)
					min = attribute[i][j];
			}

			for (int i = 0; i < n; i++) {
				attribute[i][j] = (attribute[i][j] - min) / (max - min);
			}
		}

	}
}
